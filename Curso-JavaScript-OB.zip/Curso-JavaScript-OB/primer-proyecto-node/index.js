
//Este es el mensaje de bienvenida
console.log("Esta es la puerta de entrada al proyecto")

//Esta es la parte intermedia del proyecto
console.log("Esta es la parte media del proyecto")

//Este es el mensaje de despedida
console.log("Adiós")